#define CROW_MAIN
#include "crow_all.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iostream>
#include <filesystem>


using namespace std;

string sendFile(string filename, string directory = "")
{
    std::cout << "Current working directory: " << std::filesystem::current_path() << std::endl;
	std::cout << "Wanted file: " << std::filesystem::current_path().generic_string() << "public/" << filename << std::endl;
	if (directory.length() > 1){
		filename = directory + '/' + filename;
	}
	ifstream in("public/" + filename);
	if (in)
	{
		ostringstream contents;
		contents << in.rdbuf();
		in.close();
		return contents.str();
	}
	else
	{
		return "not found";
	}
}

int main()
{
	crow::SimpleApp app;
	// "C:\shared\Week5\public\index.html"

	CROW_ROUTE(app, "/")
	([](const crow::request &req, crow::response &res, std::string filename)
	 { res.write(sendFile("index.html"));
		res.end(); 
	});

	CROW_ROUTE(app, "/getPage/<string>")
	([](const crow::request &req, crow::response &res, std::string filename)
	 { res.write(sendFile(filename));
		res.end(); 
	});

	CROW_ROUTE(app, "/getImage/<string>")
	([](const crow::request &req, crow::response &res, std::string filename)
	 { res.write(sendFile(filename, "images"));
		res.end(); 
	});

	CROW_ROUTE(app, "/getScript/<string>")
	([](const crow::request &req, crow::response &res, std::string filename)
	 { res.write(sendFile(filename, "scripts"));
		res.end(); 
	});

	CROW_ROUTE(app, "/getStyle/<string>")
	([](const crow::request &req, crow::response &res, std::string filename)
	 { res.write(sendFile(filename, "styles"));
		res.end(); 
	});

	app.port(23500).multithreaded().run();
	return 1;
}
