console.log("my cool quote")
alert("my cool quote")