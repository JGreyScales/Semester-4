file(REMOVE_RECURSE
  "CMakeFiles/workshop5.dir/main.cpp.o"
  "CMakeFiles/workshop5.dir/main.cpp.o.d"
  "workshop5"
  "workshop5.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/workshop5.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
