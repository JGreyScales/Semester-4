# Empty dependencies file for workshop5.
# This may be replaced when dependencies are built.
