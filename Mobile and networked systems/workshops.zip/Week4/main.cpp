#define CROW_MAIN

#include "crow_all.h"
#include <iostream>
using namespace std;

int main()
{
	crow::SimpleApp app;

	CROW_ROUTE(app, "/")
		( [](){
			return "Hello CSCN72050. My name is: <insert your name>";
		});

		app.port(23500).multithreaded().run();
	return 1;
}